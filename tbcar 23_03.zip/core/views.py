from django.shortcuts import render, redirect
from  core.forms import FormCliente, FormFabricante, FormVeiculo
from core.models import Cliente, Fabricante, Veiculo

def home(request):
    return render(request, 'core/index.html')

def cadastro_cliente(request):
    form  = FormCliente(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        return redirect('url_lista_clientes')
    contexto = {'form':form, 'titulo': 'Cadastro de Cliente'}
    return render(request, 'core/cadastro.html', contexto)

def lista_clientes(request):
    dados = Cliente.objects.all()
    contexto = {'dados': dados}
    return render(request, 'core/lista_clientes.html', contexto)

def lista_veiculos(request):
    dados = Veiculo.objects.all()
    contexto = {'dados': dados}
    return render(request, 'core/lista_veiculos.html', contexto)

def cadastro_veiculo(request):
    form = FormVeiculo (request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        return redirect('url_lista_veiculos')
    contexto = {'form':form,  'titulo': 'Cadastro de Veiculos'}
    return render(request, 'core/cadastro.html', contexto)

def tabela(request):
    return render(request, 'core/tabela.html')

def cadastro_fabricante(request):
    form = FormFabricante(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('url_lista_fabricantes')
    contexto = {'form': form,  'titulo': 'Cadastro de Veículo'}
    return render(request,'core/cadastro.html', contexto)

def lista_fabricantes(request):
    dados = Fabricante.objects.all()
    contexto = {'dados': dados}

    return render(request,'core/lista_fabricantes.html', contexto)

