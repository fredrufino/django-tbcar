from django.shortcuts import render, redirect
from  core.forms import FormCliente, FormFabricante, FormVeiculo
from core.models import Cliente, Fabricante, Veiculo

def home(request):
    return render(request, 'core/index.html')

def cadastro_cliente(request):
    form  = FormCliente(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        return redirect('url_lista_clientes')
    contexto = {'form':form, 'titulo': 'Cadastro de Cliente','stringBotao': 'Cadastrar'}
    return render(request, 'core/cadastro.html', contexto)

def lista_clientes(request):
    dados = Cliente.objects.all()
    contexto = {'dados': dados}
    return render(request, 'core/lista_clientes.html', contexto)

def lista_veiculos(request):
    dados = Veiculo.objects.all()
    contexto = {'dados': dados}
    return render(request, 'core/lista_veiculos.html', contexto)

def cadastro_veiculo(request):
    form = FormVeiculo (request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        return redirect('url_lista_veiculos')
    contexto = {'form':form,  'titulo': 'Cadastro de Veiculos','stringBotao': 'Cadastrar'}
    return render(request, 'core/cadastro.html', contexto)

def tabela(request):
    return render(request, 'core/tabela.html')

def cadastro_fabricante(request):
    form = FormFabricante(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('url_lista_fabricantes')
    contexto = {'form': form,  'titulo': 'Cadastro de Fabricante','stringBotao': 'Cadastrar'}
    return render(request,'core/cadastro.html', contexto)

def lista_fabricantes(request):
    dados = Fabricante.objects.all()
    contexto = {'dados': dados}

    return render(request,'core/lista_fabricantes.html', contexto)

def altera_cliente(request, id):
    objeto = Cliente.objects.get(id=id)
    form = FormCliente(request.POST or None, request.FILES or None, instance=objeto)
    form.fields['email'].widget.attrs['readonly'] = True
    if form.is_valid():
        form.save()
        return render(request,'core/dados_salvos.html',{'objeto':objeto.nome, 'url':'lista_clientes'})
    contexto = {'form':form,'titulo':'Altera', 'stringBotao': 'Salvar', 'url':'/lista_clientes/'}
    return render(request, 'core/cadastro.html', contexto)

def exclua_cliente(request, id):
    objeto = Cliente.objects.get(id=id)
    if request.POST:
        objeto.delete()
        return redirect('url_lista_clientes')
    contexto = {'objeto':objeto.nome, 'url': '/lista_clientes'}
    return render(request,'core/confirma_exclusao.html',contexto)

def altera_veiculo(request, id):
    objeto = Veiculo.objects.get(id = id)
    form = FormVeiculo(request.POST or None, request.FILES or None, instance=objeto)
    #form.fields['id_cliente'].widget.attrs['readonly'] = True
    #form.fields['id_fabricante'].widget.attrs['readonly'] = True
    contexto = {'form': form,'objeto':objeto.modelo,'stringBotao': 'Salvar', 'url':'/lista_veiculos/'}
    if form.is_valid():
        form.save()
        return render(request, 'core/dados_salvos.html', contexto)
    return render(request, 'core/cadastro.html', contexto)

def exclua_veiculo(request, id):
    objeto = Veiculo.objects.get(id = id)
    #se veiculo por request POST o usuario clicou em 'sim'
    if request.POST:
        objeto.delete()
        return redirect('url_lista_veiculos')
    contexto = {'objeto':objeto.modelo, 'url':'/lista_veiculos'}
    return render(request,'core/confirma_exclusao.html',contexto)

def altera_fabricante(request, id):
   objeto = Fabricante.objects.get(id = id)
   form = FormFabricante(request.POST or None, request.FILES or None, instance=objeto)
   contexto = {'form': form,'stringBotao': 'Salvar', 'url':'/lista_fabricantes/'}
   if form.is_valid():
        form.save()
        return render(request, 'core/dados_salvos.html', {'objeto':request.POST['descricao']})
   return render(request, 'core/cadastro.html', contexto)

def exclua_fabricante(request, id):
    objeto = Fabricante.objects.get(id = id)
    if request.POST:
        objeto.delete()
        return redirect('url_lista_fabricantes')
    contexto = {'objeto':objeto.descricao, 'url':'/lista_fabricantes'}
    return render(request,'core/confirma_exclusao.html',contexto)




