from django.db import models

class Cliente(models.Model):
    nome= models.CharField(max_length=50)
    endereco = models.CharField(max_length=100, blank=True, null=True, verbose_name='endereço')
    complemento = models.CharField(max_length=50, blank=True, null=True, verbose_name='Complemento')
    bairro = models.CharField(max_length=50, blank=True, null=True, verbose_name='Bairro')
    cidade = models.CharField(max_length=50, blank=True, null=True, verbose_name='Cidade')
    cep = models.CharField(max_length=20, blank=True, null=True, verbose_name='CEP')
    email = models.EmailField(verbose_name='E-mail')
    telefone = models.CharField(max_length=20, blank=True, null=True, verbose_name='Telefone')
    foto = models.ImageField(upload_to='fotos_clientes', blank=True, null=True, verbose_name='Foto')

    def __str__(self):
        return self.nome

    class Meta:
     verbose_name_plural = 'Clientes'

class Fabricante(models.Model):
        descricao = models.CharField(max_length=30, verbose_name='Descrição')

        def __str__(self):
            return self.descricao

        class Meta:
            verbose_name_plural = 'Fabricantes'

class Veiculo(models.Model):
        id_cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, verbose_name='Cliente')
        id_fabricante = models.ForeignKey(Fabricante, on_delete=models.CASCADE, verbose_name='Fabricante')
        modelo = models.CharField(max_length=30, verbose_name='Modelo')
        ano = models.IntegerField(default=2022, blank=True, null=True, verbose_name='Ano')
        cor = models.CharField(max_length=50, blank=True, null=True, verbose_name='Cor')
        placa = models.CharField(max_length=50, verbose_name='Placa')
        foto = models.ImageField(upload_to='fotos_veiculos', blank=True, null=True, verbose_name='Foto')

        def __str__(self):
           return self.placa

        class Meta:
            verbose_name_plural = 'Veículos'

class Tabela(models.Model):
        descricao = models.CharField(max_length=50, verbose_name='Descrição')
        valor = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Valor')

        def __str__(self):
            return f'{self.descricao}:{self.valor}'

        class Meta:
            verbose_name_plural = 'Tabelas'





